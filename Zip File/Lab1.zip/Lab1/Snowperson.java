
/**
 * Write a description of class Snowperson here.
 *
 * @author (Katie Schwerer)
 * @version (Version 1 - September 3, 2019)
 */
public class Snowperson
{
    public static void main(String[] args)
    {
        System.out.println("  ************");
        System.out.println("  *----------*");
        System.out.println("  *----------*");
        System.out.println("  *----------*");
        System.out.println("  *----------*");
        System.out.println("*---------------*");
        System.out.println("*----------->0<-*");
        System.out.println("       ***       ");
        System.out.println("     *-----*     ");
        System.out.println("   *---------*   ");
        System.out.println("  *-----------*  ");
        System.out.println("  *--O-----O--*  ");
        System.out.println("  *-----V-----*  ");
        System.out.println("   *--[___]--*   ");
        System.out.println("    *-------*    ");
        System.out.println("     *-----*     ");
        System.out.println("       ***       ");
        System.out.println("     *-----*     ");
        System.out.println("    *-------*    ");
        System.out.println("   *---------*   ");
        System.out.println("  *-----------*  ");
        System.out.println(" *-------------* ");
        System.out.println("*---------------*");
        System.out.println("*------>0<------*");
        System.out.println("*---------------*");
        System.out.println("*------>0<------*");
        System.out.println("*---------------*");
        System.out.println("*------>0<------*");
        System.out.println("*---------------*");
        System.out.println(" *-------------* ");
        System.out.println("  *-----------*  ");
        System.out.println("   *---------*   ");
        System.out.println("    *-------*    ");
        System.out.println("     *-----*     ");
        System.out.println("       ***       ");
        System.out.println("===============================================");
    }
}
