
/**
 * Write a description of class Shapes here.
 *
 * @author (Katie Schwerer)
 * @version (Version 1, September 3, 2019)
 */
public class Shapes
{
    public static void main(String[] args) {
        
        System.out.println("   *");
        System.out.println("  ***");
        System.out.println(" *****");
        System.out.println("*******");
        System.out.println(" *****");
        System.out.println("  ***");
        System.out.println("   *");
    }
}
