
/**
 * Write a description of class Periodic here.
 *
 * @author (Katie Schwerer)
 * @version (a version number or a date)
 */
public class Periodic
{
    public static void main(String[] args)
    {
        System.out.println("\u250C\u2500\u2500\u2500\u2500\u2510");
        System.out.println("\u2502 1  \u2502");
        System.out.println("\u2502 H  \u2502");
        System.out.println("\u2514\u2500\u2500\u2500\u2500\u2518");
        System.out.println("\u250C\u2500\u2500\u2500\u2500\u2510");
        System.out.println("\u2502 3  \u2502");
        System.out.println("\u2502 Li \u2502");
        System.out.println("\u2514\u2500\u2500\u2500\u2500\u2518");
        System.out.println("\u250C\u2500\u2500\u2500\u2500\u2510");
        System.out.println("\u2502 11 \u2502");
        System.out.println("\u2502 Na \u2502");
        System.out.println("\u2514\u2500\u2500\u2500\u2500\u2518");
        System.out.println("\u250C\u2500\u2500\u2500\u2500\u2510");
        System.out.println("\u2502 19 \u2502");
        System.out.println("\u2502 K  \u2502");
        System.out.println("\u2514\u2500\u2500\u2500\u2500\u2518");
    }
}
