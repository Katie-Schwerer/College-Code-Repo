
/**
 * Write a description of class Variable here.
 *
 * @author (Katie Schwerer)
 * @version (Version 1 - September 3, 2019)
 */
public class Variable
{
    public static void main(String[] args) {

        int value;

        value = 5;
        System.out.print("The value is ");
        System.out.println(value);
        System.out.println("I programmed this!");

      
    }
}